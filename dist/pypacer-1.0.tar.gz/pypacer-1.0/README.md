# PyPacer, measure the time python Callables use with ease

# What is PyPacer?
PyPacer is a python library that allows you to measure the time that it takes for Callables, such as functions, to execute
